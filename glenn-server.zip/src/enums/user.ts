export enum USER_ROLES {
    ADMIN = 'ADMIN',
    SUPER_ADMIN = 'SUPER_ADMIN',
    SELLER = 'SELLER',
    CUSTOMER = 'CUSTOMER',
}