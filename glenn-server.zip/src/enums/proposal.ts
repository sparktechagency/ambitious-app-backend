export enum PROPOSAL {
    Pending = 'Pending',
    Accept = 'Accept',
    Reject = 'Reject'
}